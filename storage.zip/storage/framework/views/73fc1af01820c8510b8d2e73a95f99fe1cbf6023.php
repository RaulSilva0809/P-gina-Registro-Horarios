<footer class="footer">
  <div class="container-fluid">
    <nav class="float-left">
      
    </nav>
    <div class="copyright float-right">
      &copy;
      <script>
        document.write(new Date().getFullYear());
        
      </script>
      All media in this page including the logo and other no specified are property of Terzett Technologix.

      <a href="http://www.terzett.tech/sites/PrivacyStatement.html" target="_blank">Privacy statement </a>

    </div>
  </div>
</footer><?php /**PATH C:\XAMPP\htdocs\horarios\proyecto_demo\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>