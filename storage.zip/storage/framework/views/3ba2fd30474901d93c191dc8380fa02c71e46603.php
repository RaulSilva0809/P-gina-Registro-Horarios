
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

<div class="content">

<!-- BUSQUEDA-->
<div class="col-md-4"> 
  <form>
    <div class="row g-3">
           

        <div class="col">
         
          <input  class="form-control mr-sm-2" name="buscar" type="search"  aria-label="Search" id='buscar' placeholder="dd-mm-aaaa">

          <input  class="form-control mr-sm-2" name="buscar2" type="search"  aria-label="Search" id='buscar2' placeholder="dd-mm-aaaa">
          <p><button type="submit" style="height:45px;" class="btn btn-ligth"><i class="material-icons">search</i>Buscar</p>
        </div>

    </div>

    <!-- PDF  -->
    <button type="button" class="btn btn-danger" data-toggle="modal" 
        data-target="#exampleModal1" data-whatever="@mdo" id="pdf">
        <i class="material-icons">file_download</i> Descargar 
    </button>
    <!-- PDF FIN -->

  </form>
</div>
<!-- BUSQUEDA FIN  -->


 <div class="container-fluid">
  <div class="row">
      
      <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Registro de Horas</h4>
            </div>
                <div class="card-body">
                    <div class="table-responsive">
                    <table class="table">
                        <thead>
                    <tr>
                        <th scope="col">Nombre</th>
                        <th scope="col">Hora</th>
                        <th scope="col">Retardo</th>
                        <th scope="col">Tipo</th>
                        <th scope="col">Fecha</th>
                        <th scope="col">Ubicacion</th>
                        <th scope="col">Longitud</th>
                        <th scope="col">Latitud</th>
                    </tr>
                    </thead>
                     <tbody>
                    <?php $__currentLoopData = $horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($hora->Nombre); ?> <?php echo e($hora->Apaterno); ?> <?php echo e($hora->Amaterno); ?></td>
                          <td><?php echo e($hora->Hora); ?></td>
                          <td><?php echo e($hora->Retardo); ?></td>
                          <td><?php echo e($hora->Tipo); ?></td>
                          <td><?php echo e($hora->Fecha); ?></td>
                          <td><?php echo e($hora->Ubicacion); ?></td>
                          <td><?php echo e($hora->Longitud); ?></td>
                          <td><?php echo e($hora->Latitud); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                    </tbody> 
                    </table>
                </div>
                <div class="row">
                        <div class="mx-auto">
                            <?php echo e($horas->appends($_GET)->links()); ?>

                        </div>
                    </div>  
                </div>
   </div>
  </div>
 </div>
</div>


<!-- Modal -->

<div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #FAD0B8;">
        <h4 class="modal-title text-white" id="exampleModalLabel">INFORME HORAS </h4>
        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        
        </div>
      <div class="modal-body">



        <div class="col">
            

        </div>

      <div class="modal-footer">

      <a href="<?php echo e(route('excel')); ?>">
        <button type="button" class="btn btn-primary float-lg-right" >
        Descargar registro</button> </a>

        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        
      </div>
    </div>
  </div>
</div>

      
      


        
        
      

</body>
</html>







<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', ['activePage' => 'horas', 'titlePage' => __('Registro de horas')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP\htdocs\horarios\proyecto_demo\resources\views/horas/tablahoras.blade.php ENDPATH**/ ?>