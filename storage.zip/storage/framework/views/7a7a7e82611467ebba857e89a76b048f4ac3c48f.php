
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-11">
        <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <?php endif; ?>
          <form method="post" action="/conteohoras" autocomplete="off" class="form-horizontal"> 
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Conteo de Horas')); ?></h4>
               
              </div>
             <!-- Acordeon busqueda  -->
                <div class="col-md-8">
                  <input  class="form-control mr-sm-2" name="nombre" type="search" id="autocomplete-search"  aria-label="Search" placeholder="Nombre">

                  <input  class="form-control mr-sm-2" name="buscar" type="search"  aria-label="Search" id='buscar' placeholder="dd-mm-aaaa">

                  <div class="input-group mb-3">
                    <input  class="form-control mr-sm-2" name="buscar2" type="search"  aria-label="Search" id='buscar2' placeholder="dd-mm-aaaa">
                    <button class="btn btn-primary" type="submit" id="button-addon2">Buscar</button>
                  </div>
                </div>
                <!-- Fin Acordeon  -->


                </div>
          </form> 

          <!-- Resultados -->
          <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Registro de Horas</h4>
            </div>
                <div class="card-body">
                    <div class="table-responsive">
                    <table class="table">
                        <thead>
                    <tr>
                        <th scope="col">Nombre</th>
                        <th scope="col">Tipo</th>
                        <th scope="col">Horas</th>
                      
                    </tr>
                    </thead>
                     <tbody>
                    <?php $__currentLoopData = $horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($hora->Nombre); ?></td>
                          <td><?php echo e($hora->Tipo); ?></td>
                          <td><?php echo e($hora->Horas); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                    </tbody> 
                    </table>
                </div>
                
                </div>
   </div>
          <!-- Fin Resultados -->

          
        </div>
      </div>
      

    </div>
  </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', ['activePage' => 'conteohoras', 'titlePage' => __('Conteo de Horas')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP\htdocs\horarios\proyecto_demo\resources\views/horas/conteohoras.blade.php ENDPATH**/ ?>