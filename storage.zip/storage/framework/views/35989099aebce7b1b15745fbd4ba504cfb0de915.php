<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
      <div class="row">

      <!-- Dashboard administrador -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Administrador')): ?>
      <div class="col-lg-3 col-md-6 col-sm-6" >
        <div class="card card-stats">
          <div class="card-header card-header-info card-header-icon">
            <div class="card-icon">
              <i class="material-icons">notifications</i>
            </div>
          <p class="card-category"><a href="/horas">Registro de horas</p></a>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">playlist_add_check</i>
                <a href="<?php echo e(route('horast')); ?>">Registro de horas</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6" >
          <div class="card card-stats">
            <div class="card-header card-header-success card-header-icon">
              <div class="card-icon">
                <i class="material-icons">admin_panel_settings</i>
              </div>
              <p class="card-category"><a href="<?php echo e(route('usuariostable')); ?>">Adminitrsación de usuarios</p></a>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">playlist_add_check</i>
                <a href="<?php echo e(route('usuariostable')); ?>">Registro de ususarios</a>
              </div>
            </div>
          </div>
        </div>

      <?php endif; ?>


        <!-- Dashboard de usuarios  -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Usuario')): ?>

        <div class="col-lg-3 col-md-6 col-sm-6" >
          <div class="card card-stats">
            <div class="card-header card-header-info card-header-icon">
              <div class="card-icon">
                <i class="material-icons">meeting_room</i>
              </div>
              <p class="card-category"><a href="/entrada">Reigstro de entrada</p></a>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">playlist_add_check</i>
                <a href="/entrada">Hora de entrada</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6" >
          <div class="card card-stats">
            <div class="card-header card-header-warning card-header-icon">
              <div class="card-icon">
                <i class="material-icons">fastfood</i>
              </div>
              <p class="card-category"><a href="/iniciocomida">Inicio de comida</p></a>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">playlist_add_check</i>
                <a href="/iniciocomida">Inicio de  tiempo de comida</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="card card-stats">
            <div class="card-header card-header-danger card-header-icon">
              <div class="card-icon">
                <i class="material-icons">no_food</i>
              </div>
              <p class="card-category"><a href="/finalcomida">Finalizacion de comida</p></a>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">playlist_add_check</i>
                <a href="/finalcomida">Termino de tiempo de comida</a>
              </div>
            </div>
          </div>
        </div>

         <div class="col-lg-3 col-md-6 col-sm-6" >
          <div class="card card-stats">
            <div class="card-header card-header-success card-header-icon">
              <div class="card-icon">
                <i class="material-icons">door_front</i>
              </div>
              <p class="card-category"><a href="/salida">Registro de salida</p></a>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">playlist_add_check</i>
                <a href="/salida">Hora de salida</a>
              </div>
            </div>
          </div>
        </div>

      <?php endif; ?>
               
          
      </div>
    </div>
  </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'dashboard', 'titlePage' => __('Inicio')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP\htdocs\horarios\proyecto_demo\resources\views/dashboard.blade.php ENDPATH**/ ?>