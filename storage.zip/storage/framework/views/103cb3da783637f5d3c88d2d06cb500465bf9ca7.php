<!DOCTYPE html>

<html>

<head>

    <title>Registro de Horas</title>

</head>

<body>

    <h1 style="text-align: center; color:darkcyan"><?php echo e($title); ?></h1>

    <h4><?php echo e($text); ?>   <?php echo e($text1); ?> </h4>

  
    <table class="table text-center" >
                    <thead>
                    <tr>
                        <th scope="col">Nombre</th>
                        <th scope="col">Hora</th>
                        <th scope="col">Valor1</th>
                        <th scope="col">Valor2</th>
                        <th scope="col">Dia</th>
                        <th scope="col">Ubicacion</th>
                        <th scope="col">Valor3</th>
                        <th scope="col">Valor4</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($hora->name); ?> <?php echo e($hora->ap); ?> <?php echo e($hora->am); ?></td>
                          <td><?php echo e($hora->hora); ?></td>
                          <td><?php echo e($hora->valor1); ?></td>
                          <td><?php echo e($hora->valor2); ?></td>
                          <td><?php echo e($hora->dia); ?></td>
                          <td><?php echo e($hora->ubicacion); ?></td>
                          <td><?php echo e($hora->valor3); ?></td>
                          <td><?php echo e($hora->valor4); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                    </tbody> 
                    </table>

</body>

</html><?php /**PATH C:\XAMPP\htdocs\horarios\proyecto_demo\resources\views/horas/prueba.blade.php ENDPATH**/ ?>