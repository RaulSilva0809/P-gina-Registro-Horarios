
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-11">
        <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <?php endif; ?>
          <form method="post" action="/horas" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
           

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Registro Home Office Entrada')); ?></h4>
               
              </div>


              <div class="card-body row g-3 ">
                <div class="col-md-10">
                <div class="bmd-form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">emoji_emotions</i>
                  </span>
                </div>

                <input type="text" name="name" class="form-control" placeholder="<?php echo e(__('Nombre')); ?>"  required>
              </div>
              <?php if($errors->has('name')): ?>
                <div id="name-error" class="error text-danger pl-3" for="name" style="display: block;">
                  <strong><?php echo e($errors->first('name')); ?></strong>
                </div>
              <?php endif; ?>
            </div>
            <div class="bmd-form-group<?php echo e($errors->has('ap') ? ' has-danger' : ''); ?>">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">man</i>
                  </span>
                </div>

                <input type="text" name="ap" class="form-control" placeholder="<?php echo e(__('Apellido Paterno')); ?>"   required>
              </div>
              <?php if($errors->has('ap')): ?>
                <div id="ap" class="error text-danger pl-3" for="ap" style="display: block;">
                  <strong><?php echo e($errors->first('ap')); ?></strong>
                </div>
              <?php endif; ?>
            </div>

            <div class="bmd-form-group<?php echo e($errors->has('am') ? ' has-danger' : ''); ?>">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">woman</i>
                  </span>
                </div>
                <input type="text" name="am" class="form-control" placeholder="<?php echo e(__('Apellido Materno')); ?>"   required>
              </div>
              <?php if($errors->has('am')): ?>
                <div id="am" class="error text-danger pl-3" for="am" style="display: block;">
                  <strong><?php echo e($errors->first('am')); ?></strong>
                </div>
              <?php endif; ?>
            </div>

            <div class="bmd-form-group<?php echo e($errors->has('idEmpleado') ? ' has-danger' : ''); ?>">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">format_list_numbered</i>
                  </span>
                </div>
                <input type="text" name="idEmpleado" class="form-control" placeholder="<?php echo e(__('Numero de empleado')); ?>" value="<?php echo e(old('idEmpleado')); ?>" required>
              </div>
              <?php if($errors->has('idEmpleado')): ?>
                <div id="idEmpleado" class="error text-danger pl-3" for="idEmpleado" style="display: block;">
                  <strong><?php echo e($errors->first('idEmpleado')); ?></strong>
                </div>
              <?php endif; ?>
            </div>


            <div class="bmd-form-group<?php echo e($errors->has('hora') ? ' has-danger' : ''); ?>">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">alarm_on</i>
                  </span>
                </div>
                <!-- <input type="text" name="hora" class="form-control"  value="9:00" required> -->
                <select name="hora" class="form-control"> 
                  <option>9:00 </option>
                  <option> 18:00</option>
                </select>

              </div>
              <?php if($errors->has('hora')): ?>
                <div id="hora" class="error text-danger pl-3" for="hora" style="display: block;">
                  <strong><?php echo e($errors->first('hora')); ?></strong>
                </div>
              <?php endif; ?>
            </div>

            

            <div class="bmd-form-group<?php echo e($errors->has('valor2') ? ' has-danger' : ''); ?>">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">rule</i>
                  </span>
                </div>
                <!-- <input type="text" name="valor2" class="form-control"  value="Entrada" placeholder="<?php echo e(__('Tipo de registro')); ?>" required> -->
                <select name="valor2" class="form-control"> 
                  <option>Entrada </option>
                  <option> Salida</option>
                </select>
              </div>
              <?php if($errors->has('valor2')): ?>
                <div id="valor2" class="error text-danger pl-3" for="valor2" style="display: block;">
                  <strong><?php echo e($errors->first('valor2')); ?></strong>
                </div>
              <?php endif; ?>
            </div>

            <?php
            $diaFormateada = date("Y-M-d");
            ?>
            <div class="bmd-form-group<?php echo e($errors->has('dia') ? ' has-danger' : ''); ?>">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">event_available</i>
                  </span>
                </div>
                <input type="text" name="dia" class="form-control"  value="<?php echo($diaFormateada) ?>" required>
              </div>
              <?php if($errors->has('dia')): ?>
                <div id="dia" class="error text-danger pl-3" for="dia" style="display: block;">
                  <strong><?php echo e($errors->first('dia')); ?></strong>
                </div>
              <?php endif; ?>
            </div>

            <div class="bmd-form-group<?php echo e($errors->has('ubicacion') ? ' has-danger' : ''); ?>">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">location_on</i>
                  </span>
                </div>
                <input type="text" name="ubicacion" id="btn" class="form-control"  placeholder="<?php echo e(__('Ubicación')); ?>"  value="Home Office" required>
              </div>
              <?php if($errors->has('ubicacion')): ?>
                <div id="ubicacion" class="error text-danger pl-3" for="ubicacion" style="display: block;">
                  <strong><?php echo e($errors->first('ubicacion')); ?></strong>
                </div>
              <?php endif; ?>
            </div>

            </div> <!-- Fin card domicilio -->
        </div>

          </form>
          <div class="card-footer justify-content-center">
            <button type="submit" class="btn btn-primary"><?php echo e(__('REGISTRAR')); ?></button>
          </div> 
      </div>
      
    </div>
    
  </div>





            


<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.app', ['activePage' => 'homeoffice', 'titlePage' => __('Home Office')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto_demo\resources\views/horas/homeoffice.blade.php ENDPATH**/ ?>