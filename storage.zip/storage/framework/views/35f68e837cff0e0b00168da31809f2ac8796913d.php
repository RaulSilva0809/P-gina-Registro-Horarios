
<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

<div class="content">
 <div class="container-fluid">
  <div class="row">
      
      <!-- <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Registro de Horas</h4>
            </div>
                <div class="card-body">
                    <div class="table-responsive">
                    <table class="table">
                        <thead>
                    <tr>
                        <th scope="col">Nombre</th>
                        <th scope="col">Tipo</th>
                        <th scope="col">Horas</th>
                      
                    </tr>
                    </thead>
                     <tbody>
                    <?php $__currentLoopData = $horas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($hora->Nombre); ?></td>
                          <td><?php echo e($hora->Tipo); ?></td>
                          <td><?php echo e($hora->Horas); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                    </tbody> 
                    </table>
                </div>
                <div class="row">
                        
                    </div>  
                </div>
   </div> -->
  </div>
 </div>
</div>




      
      


        
        
      

</body>
</html>







<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', ['activePage' => 'conteohorastabla', 'titlePage' => __('Conteo de horas')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP\htdocs\horarios\proyecto_demo\resources\views/horas/conteohorastabla.blade.php ENDPATH**/ ?>