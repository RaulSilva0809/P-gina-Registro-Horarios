
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-11">
        <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <?php endif; ?>
          <form method="post" action="/horas" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Registro hora de termino comida ')); ?></h4>
               
              </div>


              <div class="card-body row g-3 ">
                <div class="col-md-10">
                <div class="bmd-form-group<?php echo e($errors->has('name') ? ' has-danger' : ''); ?>">
                <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">emoji_emotions</i>
                  </span>
                </div>

                <input type="text" name="name" class="form-control" placeholder="<?php echo e(__('Nombre')); ?>" value="<?php echo e(auth()->user()->name); ?>" required>
              </div>
              <?php if($errors->has('name')): ?>
                <div id="name-error" class="error text-danger pl-3" for="name" style="display: block;">
                  <strong><?php echo e($errors->first('name')); ?></strong>
                </div>
              <?php endif; ?>
            </div>
            <div class="bmd-form-group<?php echo e($errors->has('ap') ? ' has-danger' : ''); ?>">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">man</i>
                  </span>
                </div>

                <input type="text" name="ap" class="form-control" placeholder="<?php echo e(__('Apellido Paterno')); ?>"  value="<?php echo e(auth()->user()->ap); ?>" required>
              </div>
              <?php if($errors->has('ap')): ?>
                <div id="ap" class="error text-danger pl-3" for="ap" style="display: block;">
                  <strong><?php echo e($errors->first('ap')); ?></strong>
                </div>
              <?php endif; ?>
            </div>

            <div class="bmd-form-group<?php echo e($errors->has('am') ? ' has-danger' : ''); ?>">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">woman</i>
                  </span>
                </div>
                <input type="text" name="am" class="form-control" placeholder="<?php echo e(__('Apellido Materno')); ?>"  value="<?php echo e(auth()->user()->am); ?>" required>
              </div>
              <?php if($errors->has('am')): ?>
                <div id="am" class="error text-danger pl-3" for="am" style="display: block;">
                  <strong><?php echo e($errors->first('am')); ?></strong>
                </div>
              <?php endif; ?>
            </div>

            <?php
            $horaFormateada = date ('H:i');
            $formato = date ('a');
            ?>
            <div class="bmd-form-group<?php echo e($errors->has('hora') ? ' has-danger' : ''); ?>">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">alarm_on</i>
                  </span>
                </div>
                <input type="text" name="hora" class="form-control"  value="<?php echo($horaFormateada) ?>" required> <input class="form-control"  value="<?php echo($formato) ?>" disabled>
              </div>
              <?php if($errors->has('hora')): ?>
                <div id="hora" class="error text-danger pl-3" for="hora" style="display: block;">
                  <strong><?php echo e($errors->first('hora')); ?></strong>
                </div>
              <?php endif; ?>
            </div>

            <div class="bmd-form-group<?php echo e($errors->has('valor2') ? ' has-danger' : ''); ?>">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">rule</i>
                  </span>
                </div>
                <input type="text" name="valor2" class="form-control"   value="Fin de comida" placeholder="<?php echo e(__('Valor de entrada')); ?>" required>
              </div>
              <?php if($errors->has('valor2')): ?>
                <div id="valor2" class="error text-danger pl-3" for="valor2" style="display: block;">
                  <strong><?php echo e($errors->first('valor2')); ?></strong>
                </div>
              <?php endif; ?>
            </div>

            <?php
            $diaFormateada = date("Y-M-d");
            ?>
            <div class="bmd-form-group<?php echo e($errors->has('dia') ? ' has-danger' : ''); ?>">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">event_available</i>
                  </span>
                </div>
                <input type="text" name="dia" class="form-control"  value="<?php echo($diaFormateada) ?>" required>
              </div>
              <?php if($errors->has('dia')): ?>
                <div id="dia" class="error text-danger pl-3" for="dia" style="display: block;">
                  <strong><?php echo e($errors->first('dia')); ?></strong>
                </div>
              <?php endif; ?>
            </div>

            <div class="bmd-form-group<?php echo e($errors->has('ubicacion') ? ' has-danger' : ''); ?>">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">location_on</i>
                  </span>
                </div>
                <input type="text" name="ubicacion" id="btn" class="form-control"  placeholder="<?php echo e(__('Ubicación')); ?>" required>
              </div>
              <?php if($errors->has('ubicacion')): ?>
                <div id="ubicacion" class="error text-danger pl-3" for="ubicacion" style="display: block;">
                  <strong><?php echo e($errors->first('ubicacion')); ?></strong>
                </div>
              <?php endif; ?>
            </div>

            <div class="bmd-form-group<?php echo e($errors->has('valor3') ? ' has-danger' : ''); ?>">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">align_vertical_top</i>
                  </span>
                </div>
                <input type="text" name="valor3" id="btn1" class="form-control"  placeholder="<?php echo e(__('Valores de longitud')); ?>" required>
              </div>
              <?php if($errors->has('valor3')): ?>
                <div id="valor3" class="error text-danger pl-3" for="valor3" style="display: block;">
                  <strong><?php echo e($errors->first('valor3')); ?></strong>
                </div>
              <?php endif; ?>
            </div>

            <div class="bmd-form-group<?php echo e($errors->has('valor4') ? ' has-danger' : ''); ?>">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">align_horizontal_left</i>
                  </span>
                </div>
                <input type="text" name="valor4"  id="btn2" class="form-control"  placeholder="<?php echo e(__('Valores de latitud')); ?>" required>
              </div>
              <?php if($errors->has('valor4')): ?>
                <div id="valor4" class="error text-danger pl-3" for="valor4" style="display: block;">
                  <strong><?php echo e($errors->first('valor4')); ?></strong>
                </div>
              <?php endif; ?>
            </div>
                      <div class="card-footer justify-content-center">
            <button type="submit" class="btn btn-primary"><?php echo e(__('REGISTRAR')); ?></button>
          </div>


            </div> <!-- Fin card domicilio -->


            

          </form>
        </div>
      </div>
      

    </div>
  </div>



<?php $__env->stopSection(); ?>

<script>

var options = {
enableHighAccuracy: false,
timeout: 5000,
maximumAge:0
}

function success(pos) {
    var crd = pos.coords,
      latMin = 19.66 ,
      latMax = 19.663,
      lonMin =-99.198 ,
      lonMax =-99.202;

  if (((crd.latitude <= latMax)&&(crd.latitude >= latMin)&&((crd.longitude >= lonMax)&&(crd.longitude <= lonMin)))){

    document.getElementById("btn").value = "Becton Dickinson "
    document.getElementById("btn1").value = crd.longitude
    document.getElementById("btn2").value = crd.latitude

  }else{
        latMin = 19.665,
        latMax = 19.667,
        lonMin =-99.22,
        lonMax =-99.221;
      if (((crd.latitude <= latMax)&&(crd.latitude >= latMin)&&((crd.longitude >= lonMax)&&(crd.longitude <= lonMin)))){
        document.getElementById("btn").value = "Oficina Terzett"
        document.getElementById("btn1").value = crd.longitude
        document.getElementById("btn2").value = crd.latitude
       }else{
            latMax = 19.6497,
            latMin = 19.6419,
            lonMin= -99.1964,
            LonMax= -99.1846;
                if (((crd.latitude <= latMax)&&(crd.latitude >= latMin)&&((crd.longitude >= lonMax)&&(crd.longitude <= lonMin)))){
                    document.getElementById("btn").value = "FORD"
                    document.getElementById("btn1").value = crd.longitude
                    document.getElementById("btn2").value = crd.latitude

  }else{
    latMin = 19.680,
    latMax = 19.681,
    lonMin = -99.219,
    lonMax = -99.22;
    if (((crd.latitude <= latMax)&&(crd.latitude >= latMin)&&((crd.longitude >= lonMax)&&(crd.longitude <= lonMin)))){
        document.getElementById("btn").value = "Casa Diego "
        document.getElementById("btn1").value = crd.longitude
        document.getElementById("btn2").value = crd.latitude
  }else{
    latMin = 19.6946,
latMax = 19.694,
lonMin = -99.2179,
lonMax = -99.218;
if (((crd.latitude <= latMax)&&(crd.latitude >= latMin)&&((crd.longitude >= lonMax)&&(crd.longitude <= lonMin)))){
    document.getElementById("btn").value = "Casa Raul"
    document.getElementById("btn1").value = crd.longitude
    document.getElementById("btn2").value = crd.latitude
  }else{
    document.getElementById("btn").value = "No se reconoce la ubicacion "
    document.getElementById("btn1").value = crd.longitude
    document.getElementById("btn2").value = crd.latitude
  }

}
  }
       }
    }    }
function error(err) {
  console.warn('ERROR(' + err.code + '): ' + err.message);
};

navigator.geolocation.getCurrentPosition(success, error, options);
  </script>
<?php echo $__env->make('layouts.app', ['activePage' => 'fincomida', 'titlePage' => __('Finalizacion de Comida')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\XAMPP\htdocs\horarios\proyecto_demo\resources\views/horas/fincomida.blade.php ENDPATH**/ ?>