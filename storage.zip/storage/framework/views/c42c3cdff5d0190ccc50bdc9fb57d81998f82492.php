
<?php $__env->startSection('content'); ?>

<div class="content">


 <div class="container-fluid">
  <div class="row">
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Administrador')): ?>
  <div class="d-grid gap-2 d-md-flex justify-content-md-end">
        <a href="usuarios/create">
        <button type="button" class="btn btn-info">
        Agregar Usuario</button> </a>
    </div>

   <div class="col-md-12">
    <div class="card">
        <div class="card-header card-header-primary">
            <h4 class="card-title ">Tabla de Usuarios</h4>
        </div>
            <div class="card-body">
                <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                        <th scope="col">ID Empleado</th>
                        <th scope="col">Nombre</th>
                        
                        <th scope="col">Correo</th>
                        <th scope="col">Rol</th>
                        <th scope="col">Creado</th>

                         <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Administrador')): ?>
                        <th scope="col">Opciones</th>
                        <?php endif; ?>
                        </tr>
                    </thead>
                     <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <th scope="row"><?php echo e($user->idEmpleado); ?></th>
                        <td><?php echo e($user->name); ?> <?php echo e($user->ap); ?> <?php echo e($user->am); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td> 
                            <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($role->nombre); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($user->created_at); ?></td>
                        

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Administrador')): ?>
                        <td class="td-actions text-left">
                            <form action="<?php echo e(route('usuarios.destroy', $user->id)); ?>" method="POST" class="eliminar">
                               
                                <a href="<?php echo e(route('usuarios.show', $user->id)); ?>" >
                                <button type="button"  class="btn btn-primary" >
                                <i class="material-icons">visibility</i> 
                                </button> </a> 

                                <a href="<?php echo e(route('usuarios.edit', $user->id)); ?>" >
                                <button type="button"  class="btn btn-success" >
                                <i class="material-icons">edit</i> 
                                </button> </a> 
                                <?php echo csrf_field(); ?> 
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" rel="tooltip" class="btn btn-danger">
                                <i class="material-icons">close</i>
                            </button>
                            </form>
                            
                        </td> <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                    </tbody> 
                    </table>

                     

                    

                </div>
                <div class="row">
                        <div class="mx-auto">
                            <?php echo e($users->appends($_GET)->links()); ?>

                        </div>
                    </div>  
                </div>
   </div>
  </div>
 </div>
</div>
     
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <script>
    $('.eliminar').submit(function(e){
        e.preventDefault();
        Swal.fire({
        title: '¿Deseas eliminar?',
        text: "¡Esta acción no se puede revertir!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si,eliminar',
        cancelButtonText: 'Cancelar'
        }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire(
            'Datos Eliminados!',
            'eliminación correcta',
            'success'
            )
            this.submit();
        }
        })
    });    
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['activePage' => 'usuariostable', 'titlePage' => __('Lista de Usuarios')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyecto_demo\resources\views/users/usuariostable.blade.php ENDPATH**/ ?>