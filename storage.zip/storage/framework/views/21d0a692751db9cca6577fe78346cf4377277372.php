<div class="sidebar" data-color="danger" data-background-color="white" data-image="<?php echo e(asset('material')); ?>/img/sidebar-5.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  
  
  <div class="logo">       
 

    <a href="home" class="simple-text logo-normal">
    <img src="<?php echo e(asset('material')); ?>/img/logo.png" alt="TERZETT TECHNOLOGIX" style="width: 17%; height: 17%; float: left; margin-left: 9%;" >
      <?php echo e(__('TERZETT TECHNOLOGIX')); ?> 
       <!-- <p style="color:black;"> <?php echo e(Auth::user()->idEmpleado); ?> </p>  
      <br>
      <p  style="color:black;" >  -->
        
        <!-- <?php 

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

 ?> </p> -->
    </a>    
  </div>

  

  <div class="sidebar-wrapper">
    <ul class="nav ml-auto" >
    
 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Administrador')): ?>
      <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          <i class="material-icons">table_chart</i>
            <p><?php echo e(__('Inicio')); ?></p>
            
        </a>
      </li>

      <li class="nav-item <?php echo e(($activePage == 'usuariostable' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('usuariostable')); ?>">
          <i class="material-icons">admin_panel_settings</i>
            <p><?php echo e(__('administrador de usuarios')); ?></p>
        </a>
      </li>

      <li class="nav-item <?php echo e(($activePage == 'horas' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('horast')); ?>">
          <i class="material-icons">notifications</i>
            <p><?php echo e(__('Registro de horas')); ?></p>
        </a>
      </li>

      <li class="nav-item <?php echo e(($activePage == 'homeoffice' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" href="/homeoffice">
          <i class="material-icons">home_work</i>
            <p><?php echo e(__('Home Office')); ?></p>
        </a>
      </li>

      <li class="nav-item <?php echo e(($activePage == 'conteohoras' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" href="/conteohoras">
          <i class="material-icons">pending_actions</i>
            <p><?php echo e(__('Conteo de Horas')); ?></p>
        </a>
      </li>
<?php endif; ?>

    

      <!-- <li class="nav-item <?php echo e(($activePage == 'perfil' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" data-toggle="collapse" href="#laravelExample" aria-expanded="true">
        <i class="material-icons">account_box</i>
          <p><?php echo e(__('Perfil de Usuario')); ?>

            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse " id="laravelExample">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage == 'perfil' ? ' active' : ''); ?>">
              <a class="nav-link" href="<?php echo e(route('users.edit')); ?>">
                <span class="sidebar-mini"> <i class="material-icons">face</i>  </span>
                <span class="sidebar-normal"><?php echo e(__('Mi Perfil')); ?> </span>
              </a>
            </li>
          </ul>
        </div>
      </li> -->
      
      <?php $users_count= DB::table('users')->count(); ?>

      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Usuario')): ?>

    <li class="nav-item<?php echo e($activePage == 'dashboard' ? ' active' : ''); ?>">
      <a class="nav-link" href="<?php echo e(route('home')); ?>">
        <i class="material-icons">table_chart</i>
          <p><?php echo e(__('Inicio')); ?></p>
      </a>
    </li>

    <li class="nav-item <?php echo e(($activePage == 'tusregistros' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" href="/tusregistros">
          <i class="material-icons">notifications</i>
            <p><?php echo e(__('Tus registros')); ?></p>
        </a>
      </li>

      <li class="nav-item <?php echo e(($activePage == 'horasentrada' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" href="/entrada">
          <i class="material-icons">meeting_room</i>
            <p><?php echo e(__('Registro de entrada')); ?></p>
        </a>
      </li>

      <li class="nav-item <?php echo e(($activePage == 'iniciocomida' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" href="/iniciocomida">
          <i class="material-icons">fastfood</i>
            <p><?php echo e(__('Inicio de comida')); ?></p>
        </a>
      </li>


    <li class="nav-item <?php echo e(($activePage == 'fincomida' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" href="/finalcomida">
          <i class="material-icons">no_food</i>
            <p><?php echo e(__('Finalizacion de comida')); ?></p>
        </a>
      </li>
      
      <li class="nav-item <?php echo e(($activePage == 'horassalida' || $activePage == 'user-management') ? ' active' : ''); ?>">
        <a class="nav-link" href="/salida">
          <i class="material-icons">door_front</i>
            <p><?php echo e(__('Registro de salida')); ?></p>
        </a>
      </li>
    
      
      <?php endif; ?>

     <br>
      
      <li class="nav-item<?php echo e($activePage == '' ? ' active' : ''); ?>">
      <a  class="dropdown-item"  href="<?php echo e(route('logout')); ?>"
        onclick="event.preventDefault();document.getElementById('logout-form').submit();">
          <i class="material-icons">power_settings_new</i>
          <p ><?php echo e(__('Cerrar Sesión')); ?></p>
      </a>
    </li>

    </ul>

  </div>
</div>

<?php $__env->startSection('js'); ?>
<script>
function openNav() {
    document.getElementById("sidr").style.width = "300px";
}

function closeNav() {
    document.getElementById("sidr").style.width = "0";
}


</script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\proyecto_demo\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>