@extends('layouts.app', ['activePage' => 'conteohorastabla', 'titlePage' => __('Conteo de horas')])
@section('content')
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

<div class="content">
 <div class="container-fluid">
  <div class="row">
      
      <!-- <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Registro de Horas</h4>
            </div>
                <div class="card-body">
                    <div class="table-responsive">
                    <table class="table">
                        <thead>
                    <tr>
                        <th scope="col">Nombre</th>
                        <th scope="col">Tipo</th>
                        <th scope="col">Horas</th>
                      
                    </tr>
                    </thead>
                     <tbody>
                    @foreach($horas as $hora)
                        <tr>
                          <td>{{$hora->Nombre}}</td>
                          <td>{{$hora->Tipo}}</td>
                          <td>{{$hora->Horas}}</td>
                        </tr>
                    @endforeach    
                    </tbody> 
                    </table>
                </div>
                <div class="row">
                        
                    </div>  
                </div>
   </div> -->
  </div>
 </div>
</div>




      
      


        
        
      

</body>
</html>







@endsection


