@extends('layouts.app', ['activePage' => 'horas', 'titlePage' => __('Conteo Horas')])
@section('content')
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

<div class="content">
<div class="col-md-14"> 
  <form>
    <div class="row g-6">
             <!-- Acordeon busqueda  -->
 
                
        <div class="col-md-8">
         
         <input  class="form-control mr-sm-2" name="fecha" type="search"  aria-label="Search" id='fecha' placeholder="dd-mm-aaaah">

         <input  class="form-control mr-sm-2" name="fecha2" type="search"  aria-label="Search" id='fecha2' placeholder="aaaa-mm-dd">
         <p><button type="submit" style="height:45px;" class="btn btn-ligth"><i class="material-icons">search</i>Buscar</p>
       </div>
                <!-- Fin Acordeon  -->


                </div>
          </form> 

          <!-- Resultados -->
          <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Conteo de Horas</h4>
            </div>
                <div class="card-body">
                    <div class="table-responsive">
                    <table class="table">
                        <thead>
                    <tr>
                        <th scope="col">Apellidos</th>
                        <th scope="col">Tipo</th>
                        <th scope="col">Horas</th>
                      
                    </tr>
                    </thead>
                     <tbody>
                    @foreach($horas as $hora)
                        <tr>
                          <td>{{$hora->Apaterno}}</td>
                          <td>{{$hora->Tipo}}</td>
                          <td>{{$hora->horas}}</td>
                          
                          
                          
                        </tr>
                    @endforeach    
                    </tbody> 
                    </table>
                </div>
                </div>
                </div>
   </div>
          <!-- Fin Resultados -->

          
        </div>
      </div>
      

    </div>
  </div>



@endsection

