@extends('layouts.app', ['activePage' => 'homeoffice', 'titlePage' => __('Home Office')])
@section('content')
<div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-11">
        @if($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach($errors->all() as $error)
            <li>{{$error}}</li>
            @endforeach
        </ul>
      </div>
      @endif
          <form method="post" action="/horas" autocomplete="off" class="form-horizontal">
            @csrf
           

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title">{{ __('Registro Home Office Entrada') }}</h4>
               
              </div>


              <div class="card-body row g-3 ">
                <div class="col-md-10">
                <div class="bmd-form-group{{ $errors->has('name') ? ' has-danger' : '' }}">
                <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">emoji_emotions</i>
                  </span>
                </div>

                <input type="text" name="name" class="form-control" placeholder="{{ __('Nombre') }}"  required>
              </div>
              @if ($errors->has('name'))
                <div id="name-error" class="error text-danger pl-3" for="name" style="display: block;">
                  <strong>{{ $errors->first('name') }}</strong>
                </div>
              @endif
            </div>
            <div class="bmd-form-group{{ $errors->has('ap') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">man</i>
                  </span>
                </div>

                <input type="text" name="ap" class="form-control" placeholder="{{ __('Apellido Paterno') }}"   required>
              </div>
              @if ($errors->has('ap'))
                <div id="ap" class="error text-danger pl-3" for="ap" style="display: block;">
                  <strong>{{ $errors->first('ap') }}</strong>
                </div>
              @endif
            </div>

            <div class="bmd-form-group{{ $errors->has('am') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">woman</i>
                  </span>
                </div>
                <input type="text" name="am" class="form-control" placeholder="{{ __('Apellido Materno') }}"   required>
              </div>
              @if ($errors->has('am'))
                <div id="am" class="error text-danger pl-3" for="am" style="display: block;">
                  <strong>{{ $errors->first('am') }}</strong>
                </div>
              @endif
            </div>

            <div class="bmd-form-group{{ $errors->has('idEmpleado') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">format_list_numbered</i>
                  </span>
                </div>
                <input type="text" name="idEmpleado" class="form-control" placeholder="{{ __('Numero de empleado') }}" value="{{ old('idEmpleado') }}" required>
              </div>
              @if ($errors->has('idEmpleado'))
                <div id="idEmpleado" class="error text-danger pl-3" for="idEmpleado" style="display: block;">
                  <strong>{{ $errors->first('idEmpleado') }}</strong>
                </div>
              @endif
            </div>


            <div class="bmd-form-group{{ $errors->has('hora') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">alarm_on</i>
                  </span>
                </div>
                <!-- <input type="text" name="hora" class="form-control"  value="9:00" required> -->
                <select name="hora" class="form-control"> 
                  <option>9:00 </option>
                  <option> 18:00</option>
                </select>

              </div>
              @if ($errors->has('hora'))
                <div id="hora" class="error text-danger pl-3" for="hora" style="display: block;">
                  <strong>{{ $errors->first('hora') }}</strong>
                </div>
              @endif
            </div>

            

            <div class="bmd-form-group{{ $errors->has('valor2') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">rule</i>
                  </span>
                </div>
                <!-- <input type="text" name="valor2" class="form-control"  value="Entrada" placeholder="{{ __('Tipo de registro') }}" required> -->
                <select name="valor2" class="form-control"> 
                  <option>Entrada </option>
                  <option> Salida</option>
                </select>
              </div>
              @if ($errors->has('valor2'))
                <div id="valor2" class="error text-danger pl-3" for="valor2" style="display: block;">
                  <strong>{{ $errors->first('valor2') }}</strong>
                </div>
              @endif
            </div>

            <?php
            $diaFormateada = date("Y-M-d");
            ?>
            <div class="bmd-form-group{{ $errors->has('dia') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">event_available</i>
                  </span>
                </div>
                <input type="text" name="dia" class="form-control"  value="<?php echo($diaFormateada) ?>" required>
              </div>
              @if ($errors->has('dia'))
                <div id="dia" class="error text-danger pl-3" for="dia" style="display: block;">
                  <strong>{{ $errors->first('dia') }}</strong>
                </div>
              @endif
            </div>

            <div class="bmd-form-group{{ $errors->has('ubicacion') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">location_on</i>
                  </span>
                </div>
                <input type="text" name="ubicacion" id="btn" class="form-control"  placeholder="{{ __('Ubicación') }}"  value="Home Office" required>
              </div>
              @if ($errors->has('ubicacion'))
                <div id="ubicacion" class="error text-danger pl-3" for="ubicacion" style="display: block;">
                  <strong>{{ $errors->first('ubicacion') }}</strong>
                </div>
              @endif
            </div>

            </div> <!-- Fin card domicilio -->
        </div>

          </form>
          <div class="card-footer justify-content-center">
            <button type="submit" class="btn btn-primary">{{ __('REGISTRAR') }}</button>
          </div> 
      </div>
      
    </div>
    
  </div>





            


@endsection









