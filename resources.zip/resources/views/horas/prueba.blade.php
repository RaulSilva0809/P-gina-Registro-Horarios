<!DOCTYPE html>

<html>

<head>

    <title>Registro de Horas</title>

</head>

<body>

    <h1 style="text-align: center; color:darkcyan">{{ $title }}</h1>

    <h4>{{$text }}   {{$text1}} </h4>

  
    <table class="table text-center" >
                    <thead>
                    <tr>
                        <th scope="col">Nombre</th>
                        <th scope="col">Hora</th>
                        <th scope="col">Valor1</th>
                        <th scope="col">Valor2</th>
                        <th scope="col">Dia</th>
                        <th scope="col">Ubicacion</th>
                        <th scope="col">Valor3</th>
                        <th scope="col">Valor4</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($horas as $hora)
                        <tr>
                          <td>{{$hora->name}} {{$hora->ap}} {{$hora->am}}</td>
                          <td>{{$hora->hora}}</td>
                          <td>{{$hora->valor1}}</td>
                          <td>{{$hora->valor2}}</td>
                          <td>{{$hora->dia}}</td>
                          <td>{{$hora->ubicacion}}</td>
                          <td>{{$hora->valor3}}</td>
                          <td>{{$hora->valor4}}</td>
                        </tr>
                    @endforeach    
                    </tbody> 
                    </table>

</body>

</html>