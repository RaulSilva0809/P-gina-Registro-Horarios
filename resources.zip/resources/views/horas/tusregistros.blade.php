@extends('layouts.app', ['activePage' => 'tusregistros', 'titlePage' => __('Registro de horas')])
@section('content')
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

<div class="content">

<!-- BUSQUEDA-->
<div class="col-md-4"> 
  <form>
    <div class="row g-3">
           

        <div class="col">
         
          <input  class="form-control mr-sm-2" name="buscar" type="search"  aria-label="Search" id='buscar' placeholder="dd-mm-aaaa">

          <input  class="form-control mr-sm-2" name="buscar2" type="search"  aria-label="Search" id='buscar2' placeholder="dd-mm-aaaa">
          <p><button type="submit" style="height:45px;" class="btn btn-ligth"><i class="material-icons">search</i>Buscar</p>
        </div>

    </div>

    <!-- PDF  -->
    <button type="button" class="btn btn-danger" data-toggle="modal" 
        data-target="#exampleModal1" data-whatever="@mdo" id="pdf">
        <i class="material-icons">file_download</i> Descargar 
    </button>
    <!-- PDF FIN -->

  </form>
</div>
<!-- BUSQUEDA FIN  -->


 <div class="container-fluid">
  <div class="row">
      
      <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title ">Registro de Horas</h4>
            </div>
                <div class="card-body">
                    <div class="table-responsive">
                    <table class="table">
                        <thead>
                    <tr>
                        <th scope="col">IdEmpleado</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Hora</th>
                        <th scope="col">Valor1</th>
                        <th scope="col">Valor2</th>
                        <th scope="col">Dia</th>
                        <th scope="col">Ubicacion</th>
                        <th scope="col">Valor3</th>
                        <th scope="col">Valor4</th>
                    </tr>
                    </thead>
                     <tbody>
                    @foreach($horas as $hora)
                        <tr>
                          <td>{{$hora->idEmpleado}}</td>
                          <td>{{$hora->Nombre}} {{$hora->Apaterno}} {{$hora->Amaterno}}</td>
                          <td>{{$hora->Hora}}</td>
                          <td>{{$hora->Retardo}}</td>
                          <td>{{$hora->Tipo}}</td>
                          <td>{{$hora->Fecha}}</td>
                          <td>{{$hora->Ubicacion}}</td>
                          <td>{{$hora->Longitud}}</td>
                          <td>{{$hora->Latitud}}</td>
                        </tr>
                    @endforeach    
                    </tbody> 
                    </table>
                </div>
                <div class="row">
                        <div class="mx-auto">
                            {{$horas->appends($_GET)->links()}}
                        </div>
                    </div>  
                </div>
   </div>
  </div>
 </div>
</div>


<!-- Modal -->

<div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #FAD0B8;">
        <h4 class="modal-title text-white" id="exampleModalLabel">INFORME HORAS </h4>
        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        
        </div>
      <div class="modal-body">



        <div class="col">
            

        </div>

      <div class="modal-footer">

      <a href="{{route('excel')}}">
        <button type="button" class="btn btn-primary float-lg-right" >
        Descargar registro</button> </a>

        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        
      </div>
    </div>
  </div>
</div>

      
      


        
        
      

</body>
</html>







@endsection


