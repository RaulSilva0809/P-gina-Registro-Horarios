<div class="sidebar" data-color="danger" data-background-color="white" data-image="{{ asset('material') }}/img/sidebar-5.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  
  
  <div class="logo">       
 

    <a href="home" class="simple-text logo-normal">
    <img src="{{ asset('material') }}/img/logo.png" alt="TERZETT TECHNOLOGIX" style="width: 17%; height: 17%; float: left; margin-left: 9%;" >
      {{ __('TERZETT TECHNOLOGIX') }} 
       <!-- <p style="color:black;"> {{ Auth::user()->idEmpleado }} </p>  
      <br>
      <p  style="color:black;" >  -->
        
        <!-- <?php 

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

 ?> </p> -->
    </a>    
  </div>

  

  <div class="sidebar-wrapper">
    <ul class="nav ml-auto" >
    
 @can('Administrador')
      <li class="nav-item{{ $activePage == 'dashboard' ? ' active' : '' }}">
        <a class="nav-link" href="{{ route('home') }}">
          <i class="material-icons">table_chart</i>
            <p>{{ __('Inicio') }}</p>
            
        </a>
      </li>

      <li class="nav-item {{ ($activePage == 'usuariostable' || $activePage == 'user-management') ? ' active' : '' }}">
        <a class="nav-link" href="{{ route('usuariostable') }}">
          <i class="material-icons">admin_panel_settings</i>
            <p>{{ __('administrador de usuarios') }}</p>
        </a>
      </li>

      <li class="nav-item {{ ($activePage == 'horas' || $activePage == 'user-management') ? ' active' : '' }}">
        <a class="nav-link" href="{{ route('horast') }}">
          <i class="material-icons">notifications</i>
            <p>{{ __('Registro de horas') }}</p>
        </a>
      </li>

      <li class="nav-item {{ ($activePage == 'homeoffice' || $activePage == 'user-management') ? ' active' : '' }}">
        <a class="nav-link" href="/homeoffice">
          <i class="material-icons">home_work</i>
            <p>{{ __('Home Office') }}</p>
        </a>
      </li>

      <li class="nav-item {{ ($activePage == 'conteohoras' || $activePage == 'user-management') ? ' active' : '' }}">
        <a class="nav-link" href="/conteohoras">
          <i class="material-icons">pending_actions</i>
            <p>{{ __('Conteo de Horas') }}</p>
        </a>
      </li>
@endcan

    

      <!-- <li class="nav-item {{ ($activePage == 'perfil' || $activePage == 'user-management') ? ' active' : '' }}">
        <a class="nav-link" data-toggle="collapse" href="#laravelExample" aria-expanded="true">
        <i class="material-icons">account_box</i>
          <p>{{ __('Perfil de Usuario') }}
            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse " id="laravelExample">
          <ul class="nav">
            <li class="nav-item{{ $activePage == 'perfil' ? ' active' : '' }}">
              <a class="nav-link" href="{{ route('users.edit') }}">
                <span class="sidebar-mini"> <i class="material-icons">face</i>  </span>
                <span class="sidebar-normal">{{ __('Mi Perfil') }} </span>
              </a>
            </li>
          </ul>
        </div>
      </li> -->
      
      <?php $users_count= DB::table('users')->count(); ?>

      @can('Usuario')

    <li class="nav-item{{ $activePage == 'dashboard' ? ' active' : '' }}">
      <a class="nav-link" href="{{ route('home') }}">
        <i class="material-icons">table_chart</i>
          <p>{{ __('Inicio') }}</p>
      </a>
    </li>

    <li class="nav-item {{ ($activePage == 'tusregistros' || $activePage == 'user-management') ? ' active' : '' }}">
        <a class="nav-link" href="/tusregistros">
          <i class="material-icons">notifications</i>
            <p>{{ __('Tus registros') }}</p>
        </a>
      </li>

      <li class="nav-item {{ ($activePage == 'horasentrada' || $activePage == 'user-management') ? ' active' : '' }}">
        <a class="nav-link" href="/entrada">
          <i class="material-icons">meeting_room</i>
            <p>{{ __('Registro de entrada') }}</p>
        </a>
      </li>

      <li class="nav-item {{ ($activePage == 'iniciocomida' || $activePage == 'user-management') ? ' active' : '' }}">
        <a class="nav-link" href="/iniciocomida">
          <i class="material-icons">fastfood</i>
            <p>{{ __('Inicio de comida') }}</p>
        </a>
      </li>


    <li class="nav-item {{ ($activePage == 'fincomida' || $activePage == 'user-management') ? ' active' : '' }}">
        <a class="nav-link" href="/finalcomida">
          <i class="material-icons">no_food</i>
            <p>{{ __('Finalizacion de comida') }}</p>
        </a>
      </li>
      
      <li class="nav-item {{ ($activePage == 'horassalida' || $activePage == 'user-management') ? ' active' : '' }}">
        <a class="nav-link" href="/salida">
          <i class="material-icons">door_front</i>
            <p>{{ __('Registro de salida') }}</p>
        </a>
      </li>
    
      
      @endcan

     <br>
      
      <li class="nav-item{{ $activePage == '' ? ' active' : '' }}">
      <a  class="dropdown-item"  href="{{ route('logout') }}"
        onclick="event.preventDefault();document.getElementById('logout-form').submit();">
          <i class="material-icons">power_settings_new</i>
          <p >{{ __('Cerrar Sesión') }}</p>
      </a>
    </li>

    </ul>

  </div>
</div>

@section('js')
<script>
function openNav() {
    document.getElementById("sidr").style.width = "300px";
}

function closeNav() {
    document.getElementById("sidr").style.width = "0";
}


</script>
@endsection