@extends('layouts.app', ['activePage' => 'dashboard', 'titlePage' => __('Inicio')])

@section('content')
<div class="content">
    <div class="container-fluid">
      <div class="row">

      <!-- Dashboard administrador -->
        @can('Administrador')
      <div class="col-lg-3 col-md-6 col-sm-6" >
        <div class="card card-stats">
          <div class="card-header card-header-info card-header-icon">
            <div class="card-icon">
              <i class="material-icons">notifications</i>
            </div>
          <p class="card-category"><a href="/horas">Registro de horas</p></a>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">playlist_add_check</i>
                <a href="{{ route('horast') }}">Registro de horas</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6" >
          <div class="card card-stats">
            <div class="card-header card-header-success card-header-icon">
              <div class="card-icon">
                <i class="material-icons">admin_panel_settings</i>
              </div>
              <p class="card-category"><a href="{{ route('usuariostable') }}">Adminitrsación de usuarios</p></a>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">playlist_add_check</i>
                <a href="{{ route('usuariostable') }}">Registro de ususarios</a>
              </div>
            </div>
          </div>
        </div>

      @endcan


        <!-- Dashboard de usuarios  -->
        @can('Usuario')

        <div class="col-lg-3 col-md-6 col-sm-6" >
          <div class="card card-stats">
            <div class="card-header card-header-info card-header-icon">
              <div class="card-icon">
                <i class="material-icons">meeting_room</i>
              </div>
              <p class="card-category"><a href="/entrada">Reigstro de entrada</p></a>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">playlist_add_check</i>
                <a href="/entrada">Hora de entrada</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6" >
          <div class="card card-stats">
            <div class="card-header card-header-warning card-header-icon">
              <div class="card-icon">
                <i class="material-icons">fastfood</i>
              </div>
              <p class="card-category"><a href="/iniciocomida">Inicio de comida</p></a>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">playlist_add_check</i>
                <a href="/iniciocomida">Inicio de  tiempo de comida</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="card card-stats">
            <div class="card-header card-header-danger card-header-icon">
              <div class="card-icon">
                <i class="material-icons">no_food</i>
              </div>
              <p class="card-category"><a href="/finalcomida">Finalizacion de comida</p></a>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">playlist_add_check</i>
                <a href="/finalcomida">Termino de tiempo de comida</a>
              </div>
            </div>
          </div>
        </div>

         <div class="col-lg-3 col-md-6 col-sm-6" >
          <div class="card card-stats">
            <div class="card-header card-header-success card-header-icon">
              <div class="card-icon">
                <i class="material-icons">door_front</i>
              </div>
              <p class="card-category"><a href="/salida">Registro de salida</p></a>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">playlist_add_check</i>
                <a href="/salida">Hora de salida</a>
              </div>
            </div>
          </div>
        </div>

      @endcan
               
          
      </div>
    </div>
  </div>



@endsection