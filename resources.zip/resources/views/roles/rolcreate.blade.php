@extends('layouts.app', ['activePage' => 'roles', 'titlePage' => __('Nueva roles')])
@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
        @if($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach($errors->all() as $error)
            <li>{{$error}}</li>
            @endforeach
        </ul>
      </div>
      @endif
          <form method="post" action="/roles" autocomplete="off" class="form-horizontal">
            @csrf
            @method('post')

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title">{{ __('Datos ') }}</h4>
               
              </div>
              <div class="card-body row g-3 ">
                <div class="col-md-3">
                      <label for="nombre" class="form-label">Nombre</label>
                      <input type="text" class="form-control is-valid " name="nombre"  required >
                      <div class="valid-feedback">
                        Looks good!
                      </div>
                </div>
                <div class="col-md-3">
                      <label for="descripcion" class="form-label">Descripción</label>
                      <input type="text" class="form-control is-valid" name="descripcion"  required >
                      <div class="valid-feedback">
                        Looks good!
                      </div>
                </div>
                

              </div> <!-- Fin card -->
            </div> <!-- Fin card personal -->
            <div class="card ">
                <button type="submit" class="btn btn-primary">GUARDAR</button>

            </div> <!-- Fin card domicilio -->


            

          </form>
        </div>
      </div>
      

    </div>
  </div>
@endsection