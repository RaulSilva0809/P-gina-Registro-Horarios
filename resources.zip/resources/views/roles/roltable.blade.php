
@extends('layouts.app', ['activePage' => 'roles', 'titlePage' => __('Lista de Roles')])
@section('content')
<div class="content">
<!-- @can('SuperAdmin')
    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
        <a href="roles/create">
        <button type="button" class="btn btn-info">
        Agregar Rol</button> </a>
    </div>
@endcan -->
 <div class="container-fluid">
  <div class="row">
  <div class="col-md-4">.
      <a href="/home">
        <button type="button" class="btn btn-ligth">
        <i class="material-icons">chevron_left</i> Regresar </button> </a>
    </div> 
   <div class="col-md-12">
    <div class="card">
        <div class="card-header card-header-primary">
            <h4 class="card-title ">Tabla de Roles</h4>
        </div>
            <div class="card-body">
                <div class="table-responsive">
                <table class="table text-center">
                    <thead>
                        <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Descripción</th>
                        @can('SuperAdmin')
                        <th scope="col">Opciones</th>
                        @endcan
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($roles as $rol)
                        <tr>
                        <th scope="row">{{$rol->id}}</th> 
                        <td>{{$rol->nombre}}</td>
                        <td>{{$rol->descripcion}}</td>
                        @can('SuperAdmin')
                        <td class="td-actions" style="text-align: center;">
                            <form action="{{route('roles.destroy', $rol->id)}}" method="POST" class="eliminar">
                                <a href="{{ route('roles.edit', $rol->id)}}" >
                                <button type="button"  class="btn btn-success" >
                                <i class="material-icons">edit</i> 
                                </button> </a> 
                                @csrf 
                                @method('DELETE')
                                <!-- <button type="submit" rel="tooltip" class="btn btn-danger">
                                <i class="material-icons">close</i>
                            </button> -->
                            </form>
                            
                        </td> @endcan
                        </tr>
                    @endforeach    
                    </tbody>
                    </table>

                </div>
                </div>
   </div>
  </div>
 </div>
</div>
     
@endsection

@section('js')
<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <script>
    $('.eliminar').submit(function(e){
        e.preventDefault();
        Swal.fire({
        title: '¿Deseas eliminar?',
        text: "¡Esta acción no se puede revertir!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si,eliminar',
        cancelButtonText: 'Cancelar'
        }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire(
            'Datos Eliminados!',
            'eliminación correcta',
            'success'
            )
            this.submit();
        }
        })
    });    
    </script>

@endsection