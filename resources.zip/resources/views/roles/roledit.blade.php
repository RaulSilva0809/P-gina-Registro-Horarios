@extends('layouts.app', ['activePage' => 'roles', 'titlePage' => __('Editar roles')])
@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
      <div class="col-md-4">.
      <a href="/roles">
        <button type="button" class="btn btn-ligth">
        <i class="material-icons">chevron_left</i> Regresar </button> </a>
    </div> 
        <div class="col-md-12">
        @if($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach($errors->all() as $error)
            <li>{{$error}}</li>
            @endforeach
        </ul>
      </div>
      @endif
          <form method="post" action="{{route('roles.update', $rol->id)}}" autocomplete="off" class="form-horizontal">
          @method('PATCH')
            @csrf
            

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title">{{ __('Datos') }}</h4>
               
              </div>
              <div class="card-body row g-3 ">
                <div class="col-md-3">
                      <label for="nombre" class="form-label">Nombre</label>
                      <input readonly type="text" class="form-control is-valid" name="nombre"  value="{{$rol->nombre}}" required>
                      <div class="valid-feedback">
                        Looks good!
                      </div>
                </div>
                <div class="col-md-3">
                      <label for="descripcion" class="form-label">Descripción</label>
                      <input type="text" class="form-control is-valid" name="descripcion" value="{{$rol->descripcion}}"  required>
                      <div class="valid-feedback">
                        Looks good!
                      </div>
                </div>
                

              </div> <!-- Fin card -->
            </div> <!-- Fin card personal -->

            
              
          <form class="editar">
          <button type="submit" class="btn btn-primary" >GUARDAR</button>
          </form>
              
              

            </div> <!-- Fin card domicilio -->


            

          </form>
        </div>
      </div>
      

    </div>
  </div>
@endsection

@section('js')
<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    @if(session('editar') == 'ok')
    <script>
        $('.editar').submit(function(e){
        e.preventDefault();
        Swal.fire({
          icon: 'success',
          title: 'Oops...',
          text: 'Something went wrong!',
          
        })
        this.submit();
    });   
      </script>
    @endif

    
    

@endsection