@extends('layouts.app', ['activePage' => 'usuariostable', 'titlePage' => __('Nuevo usuario')])
 @section('content')

 

  <div class="content">
    <div class="container-fluid">
    <div class="col-md-4">.
      <a href="/usuariostable">
        <button type="button" class="btn btn-ligth">
        <i class="material-icons">chevron_left</i> Regresar </button> </a>
    </div>


      <div class="row">
        <div class="col-md-12">
        @if($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach($errors->all() as $error)
            <li>{{$error}}</li>
            @endforeach
        </ul>
      </div>
      @endif
          <form method="post" action="/usuarios" autocomplete="off" class="form-horizontal" enctype="multipart/form-data">
            @csrf
            @method('post')



          <div class="card card-login card-hidden mb-3">
          <div class="card-header card-header-primary">
          <h4 class="card-title"><strong>{{ __('Registrar usuario') }}</strong></h4>
            
          </div>
          <div class="card-body ">

          <!-- <div class="bmd-form-group{{ $errors->has('id') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">how_to_reg</i>
                  </span>
                </div>

                <input type="text" name="id" class="form-control" placeholder="{{ __('ID_Usuario') }}" value="{{ old('id') }}" required>
              </div>
              @if ($errors->has('id'))
                <div id="id-error" class="error text-danger pl-3" for="id" style="display: block;">
                  <strong>{{ $errors->first('id') }}</strong>
                </div>
              @endif
            </div> -->

           
            <div class="bmd-form-group{{ $errors->has('name') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">emoji_emotions</i>
                  </span>
                </div>

                <input type="text" name="name" class="form-control" placeholder="{{ __('Nombre') }}" value="{{ old('name') }}" required>
              </div>
              @if ($errors->has('name'))
                <div id="name-error" class="error text-danger pl-3" for="name" style="display: block;">
                  <strong>{{ $errors->first('name') }}</strong>
                </div>
              @endif
            </div>




            <div class="bmd-form-group{{ $errors->has('ap') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">man</i>
                  </span>
                </div>

                <input type="text" name="ap" class="form-control" placeholder="{{ __('Apellido Paterno') }}" value="{{ old('ap') }}" required>
              </div>
              @if ($errors->has('ap'))
                <div id="ap" class="error text-danger pl-3" for="ap" style="display: block;">
                  <strong>{{ $errors->first('ap') }}</strong>
                </div>
              @endif
            </div>

            <div class="bmd-form-group{{ $errors->has('am') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">woman</i>
                  </span>
                </div>
                <input type="text" name="am" class="form-control" placeholder="{{ __('Apellido Materno') }}" value="{{ old('am') }}" required>
              </div>
              @if ($errors->has('am'))
                <div id="am" class="error text-danger pl-3" for="am" style="display: block;">
                  <strong>{{ $errors->first('am') }}</strong>
                </div>
              @endif
            </div>

            <div class="bmd-form-group{{ $errors->has('idEmpleado') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">format_list_numbered</i>
                  </span>
                </div>
                <input type="text" name="idEmpleado" class="form-control" placeholder="{{ __('Numero de empleado') }}" value="{{ old('idEmpleado') }}" required>
              </div>
              @if ($errors->has('idEmpleado'))
                <div id="idEmpleado" class="error text-danger pl-3" for="idEmpleado" style="display: block;">
                  <strong>{{ $errors->first('idEmpleado') }}</strong>
                </div>
              @endif
            </div>

             <div class="bmd-form-group{{ $errors->has('email') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                    <i class="material-icons">email</i>
                  </span>
                </div>
                <input type="email" name="email" id="email" class="form-control"  oninput="myFunction()"  placeholder="{{ __('Correo Electronico') }}" value="{{ old('email') }}" required>
              </div>
              @if ($errors->has('email'))
                <div id="email-error" class="error text-danger pl-3" for="email" style="display: block;">
                  <strong>{{ $errors->first('email') }}</strong>
                </div>
              @endif
            </div>

           

            <div class="bmd-form-group{{ $errors->has('rol') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">people_alt</i>
                  </span>
                </div>
                <select name="rol" class="form-control">
                <option selected disabled >Elige un rol para este usuario...</option>
                @foreach($roles as $role)
                <option value="{{$role->id}}">{{$role->nombre}} </option>
                @endforeach
              </select>
              </div>
            </div>

            <div class="bmd-form-group{{ $errors->has('descripcion') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">description</i>
                  </span>
                </div>
                <textarea name="descripcion" class="form-control" placeholder="{{ __('Descripción del puesto del usuario') }}" value="{{ old('descripcion') }}" required></textarea>
              </div>
              @if ($errors->has('descripcion'))
                <div id="descripcion" class="error text-danger pl-3" for="descripcion" style="display: block;">
                  <strong>{{ $errors->first('descripcion') }}</strong>
                </div>
              @endif
            </div>


            <p>{{ __('Copiar la siguiente contraseña en "Confirmar contraseña"') }}</p>
             <div class="bmd-form-group{{ $errors->has('password') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                    <i class="material-icons">lock</i>
                  </span>
                </div>
                
                <?php
                $caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890';
                $longitud = 10;
              ?>

                <input type="text" name="password" id="password" class="form-control"  value="<?php echo substr(str_shuffle($caracteres),0,$longitud);?>" required>

              </div>
              @if ($errors->has('password'))
                <div id="password-error" class="error text-danger pl-3" for="password" style="display: block;">
                  <strong>{{ $errors->first('password') }}</strong>
                </div>
              @endif
            </div> 


            <div class="bmd-form-group{{ $errors->has('password_confirmation') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                    <i class="material-icons">enhanced_encryption</i>
                  </span>
                </div>
                <input type="text" name="password_confirmation" id="password_confirmation" class="form-control" placeholder="{{ __('Confirmar contraseña') }}" required>
              </div>
              @if ($errors->has('password_confirmation'))
                <div id="password_confirmation-error" class="error text-danger pl-3" for="password_confirmation" style="display: block;">
                  <strong>{{ $errors->first('password_confirmation') }}</strong>
                </div>
              @endif
            </div> 


            <div class="bmd-form-group{{ $errors->has('url') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">link</i>
                  </span>
                </div>
                <textarea name="url" class="form-control" id="url" placeholder="{{ __('URL de inicio de sesion') }}" value="https://horarios.terzett.com/ "  required></textarea>
              </div>
              @if ($errors->has('url'))
                <div id="url" class="error text-danger pl-3" for="url" style="display: block;">
                  <strong>{{ $errors->first('url') }}</strong>
                </div>
              @endif
            </div>

            <!-- Card Foto -->
  <div class="card-deck mt-3">

<div class="card-group mt-3">
<!-- Nombre con imagen -->
<div class="card text-center border-info">
  <div class="card-body" style="background-color: #CCFAE5;" >
    <h4 class="card-title">Foto de perfil</h4>
  <div class="author">
          <img   class="avatar border-gray" src="{{asset('material')}}/img/perfil1.jpg" style="width: 30%; height: 70%;">
          <input type="file" name="imagen"  id="file" accept="image/*" capture="camera" required /> 
        </div>
  </div>
</div>  

 <!-- Fin de Nombre con imagen -->

 <!-- Card de QR -->

<div class="card text-center border-info">
  <div class="card-body" style="background-color: #F7B793;">
    <h4 class="card-title">Codigo QR</h4>
    <p class="card-text">Para generar el codigo QR del colaborador es necesario acceder
                                  a la ruta <a href="https://www.qrcode-monkey.com/">https://www.qrcode-monkey.com/</a>
                                  y colocar la URL generada en la parte de arriba para que posteriormente sea descargado
                                  este QR y asi mismo sea guardada en esta seccion. </p>
    <input type="file" name="imagen2"  id="file" accept="image/*" capture="camera" required /> 
  </div>
</div>          
<!-- Fin de Card de QR -->

            
          
          </div>
          <div class="card-footer justify-content-center">
            <button type="submit" class="btn btn-primary">{{ __('REGISTRAR') }}</button>
          </div>
            </div>
      

    </div>
  </div>

  
             

    </div>
@endsection 

<!-- URL -->
<script> 
function myFunction() {
  var x = document.getElementById("email").value;
  var y = document.getElementById("password").value;
  document.getElementById("url").innerHTML = "https://horarios.terzett.com/" + x + "/" + y;
}




</script>

