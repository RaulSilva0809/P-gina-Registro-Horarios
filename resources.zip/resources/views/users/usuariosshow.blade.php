@extends('layouts.app', ['activePage' => 'usuariostable', 'titlePage' => __('Datos personales')])
@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
         <div class="col-md-4">.
      <a href="/usuariostable">
        <button type="button" class="btn btn-ligth">
        <i class="material-icons">chevron_left</i> Regresar </button> </a>
    </div>
      
    
        <div class="col-md-12">
        @if($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach($errors->all() as $error)
            <li>{{$error}}</li>
            @endforeach
        </ul>
      </div>
      @endif
        <form method="post" action="{{route('usuarios.update', $user->id)}}" autocomplete="off" class="form-horizontal">
          @method('PATCH')
            @csrf

            <div class="card card-login card-hidden mb-3">
          <div class="card-header card-header-primary">
            <h4 class="card-title"><strong>{{ __('Datos del colaborador') }}</strong></h4>
            
          </div>
          <div class="card-body ">
           
            <div class="bmd-form-group{{ $errors->has('name') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">emoji_emotions</i>
                  </span>
                </div>
                <input type="text" readonly name="name" class="form-control" placeholder="{{ __('Nombre') }}"  value="{{$user->name}}" required>
              </div>
              @if ($errors->has('name'))
                <div id="name-error" class="error text-danger pl-3" for="name" style="display: block;">
                  <strong>{{ $errors->first('name') }}</strong>
                </div>
              @endif
            </div>

            <div class="bmd-form-group{{ $errors->has('ap') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">man</i>
                  </span>
                </div>

                <input type="text" name="ap" readonly class="form-control" placeholder="{{ __('Apellido Paterno') }}" value="{{ $user->ap }}" required>
              </div>
              @if ($errors->has('ap'))
                <div id="ap" class="error text-danger pl-3" for="ap" style="display: block;">
                  <strong>{{ $errors->first('ap') }}</strong>
                </div>
              @endif
            </div>

            <div class="bmd-form-group{{ $errors->has('am') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">woman</i>
                  </span>
                </div>
                <input type="text" name="am" readonly class="form-control" placeholder="{{ __('Apellido Materno') }}" value="{{ $user->am }}" required>
              </div>
              @if ($errors->has('am'))
                <div id="am" class="error text-danger pl-3" for="am" style="display: block;">
                  <strong>{{ $errors->first('am') }}</strong>
                </div>
              @endif
            </div>

            <div class="bmd-form-group{{ $errors->has('idEmpleado') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">format_list_numbered</i>
                  </span>
                </div>
                <input type="text" name="idEmpleado" readonly class="form-control" placeholder="{{ __('Id del Empleado') }}" value="{{ $user->idEmpleado }}" required>
              </div>
              @if ($errors->has('idEmpleado'))
                <div id="idEmpleado" class="error text-danger pl-3" for="idEmpleado" style="display: block;">
                  <strong>{{ $errors->first('idEmpleado') }}</strong>
                </div>
              @endif
            </div>



            <div class="bmd-form-group{{ $errors->has('email') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                    <i class="material-icons">email</i>
                  </span>
                </div>
                <input type="email" name="email" readonly class="form-control" placeholder="{{ __('Correo Electronico') }}" value="{{$user->email}}" required>
              </div>
              @if ($errors->has('email'))
                <div id="email-error" class="error text-danger pl-3" for="email" style="display: block;">
                  <strong>{{ $errors->first('email') }}</strong>
                </div>
              @endif
            </div>
           
            

            <div class="bmd-form-group{{ $errors->has('rol') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">people_alt</i>
                  </span>
                </div>
                @foreach($roles as $role)
                @if($role->nombre == str_replace(array('["','"]'), '', $user->tieneRol()))
                <input type="email" name="rol" readonly class="form-control" placeholder="{{$role->id}}" value="{{$role->nombre}}" required>
                    @else

                    @endif
                @endforeach
              </select>
              </div>
            </div>

            <div class="bmd-form-group{{ $errors->has('descripcion') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">description</i>
                  </span>
                </div>
                <input type="text" name="descripcion" readonly class="form-control" placeholder="{{ __('Descripción del Rol') }}" value="{{ $user->descripcion }}" required>
              </div>
              @if ($errors->has('descripcion'))
                <div id="descripcion" class="error text-danger pl-3" for="descripcion" style="display: block;">
                  <strong>{{ $errors->first('descripcion') }}</strong>
                </div>
              @endif
            </div>

            <div class="bmd-form-group{{ $errors->has('url') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">link</i>
                  </span>
                </div>
                <input type="text" name="url" readonly class="form-control" placeholder="{{ __('Url') }}" value="{{ $user->url}}" required>
              </div>
              @if ($errors->has('url'))
                <div id="url" class="error text-danger pl-3" for="url" style="display: block;">
                  <strong>{{ $errors->first('url') }}</strong>
                </div>
              @endif
            </div>


          </div>

            </div>
      
<!-- Nombre con imagen -->

<div class="card-deck mt-3">

<div class="card-group mt-3">

<div class="card text-center border-info">
  <div class="card-body" style="background-color: #CCFAE5;" >
    <h4 class="card-title">Foto de perfil</h4>
  <div class="author">
  <img    src="{{asset('fotoperfil/'.$user->imagen)}}" style="width: 25%; height: 25%;">

        </div>
  </div>
</div>  

 <!-- Fin de Nombre con imagen -->

 <!-- Card de QR -->

<div class="card text-center border-info">
  <div class="card-body" style="background-color: #F7B793;">
    <h4 class="card-title">Codigo QR</h4>
  <img  src="{{asset('fotoqr/'.$user->imagen2)}}"  style="width: 30%; height: 85%;">


  </div>
</div>          
<!-- Fin de Card de QR -->

            
      </div>

    </div>
  </div>
@endsection