@extends('layouts.app', ['activePage' => 'usuariostable', 'titlePage' => __('Edicion de informacion')])
@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
      <div class="col-md-4">.
      <a href="/usuariostable">
        <button type="button" class="btn btn-ligth">
        <i class="material-icons">chevron_left</i> Regresar </button> </a>
    </div> 
    
        <div class="col-md-12">
        @if($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach($errors->all() as $error)
            <li>{{$error}}</li>
            @endforeach
        </ul>
      </div>
      @endif
        <form method="post" action="{{route('usuarios.update', $user->id)}}" autocomplete="off" class="form-horizontal" enctype="multipart/form-data">
          @method('PATCH')
            @csrf

            <div class="card card-login card-hidden mb-3">
          <div class="card-header card-header-primary">
            <h4 class="card-title"><strong>{{ __('Datos Personales') }}</strong></h4>
            
          </div>
          <div class="card-body ">
           
            <div class="bmd-form-group{{ $errors->has('name') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">emoji_emotions</i>
                  </span>
                </div>
                <input type="text" name="name" class="form-control" placeholder="{{ __('Nombre') }}"  value="{{ $user->name }}" required>
              </div>
              @if ($errors->has('name'))
                <div id="name-error" class="error text-danger pl-3" for="name" style="display: block;">
                  <strong>{{ $errors->first('name') }}</strong>
                </div>
              @endif
            </div>

            <div class="bmd-form-group{{ $errors->has('ap') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">man</i>
                  </span>
                </div>

                <input type="text" name="ap" class="form-control" placeholder="{{ __('Apellido Paterno') }}" value="{{ $user->ap }}" required>
              </div>
              @if ($errors->has('ap'))
                <div id="ap" class="error text-danger pl-3" for="ap" style="display: block;">
                  <strong>{{ $errors->first('ap') }}</strong>
                </div>
              @endif
            </div>

            <div class="bmd-form-group{{ $errors->has('am') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">woman</i>
                  </span>
                </div>
                <input type="text" name="am" class="form-control" placeholder="{{ __('Apellido Materno') }}" value="{{ $user->am }}" required>
              </div>
              @if ($errors->has('am'))
                <div id="am" class="error text-danger pl-3" for="am" style="display: block;">
                  <strong>{{ $errors->first('am') }}</strong>
                </div>
              @endif
            </div>


            <div class="bmd-form-group{{ $errors->has('idEmpleado') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">format_list_numbered</i>
                  </span>
                </div>
                <input type="text" name="idEmpleado" class="form-control" placeholder="{{ __('Numero de empleado') }}" value="{{ $user->idEmpleado }}" required>
              </div>
              @if ($errors->has('idEmpleado'))
                <div id="idEmpleado" class="error text-danger pl-3" for="idEmpleado" style="display: block;">
                  <strong>{{ $errors->first('idEmpleado') }}</strong>
                </div>
              @endif
            </div>



            <div class="bmd-form-group{{ $errors->has('email') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                    <i class="material-icons">email</i>
                  </span>
                </div>
                <input type="email" name="email" class="form-control" placeholder="{{ __('Correo Electronico') }}" value="{{$user->email}}" required>
              </div>
              @if ($errors->has('email'))
                <div id="email-error" class="error text-danger pl-3" for="email" style="display: block;">
                  <strong>{{ $errors->first('email') }}</strong>
                </div>
              @endif
            </div>
           
            

            <div class="bmd-form-group{{ $errors->has('rol') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">people_alt</i>
                  </span>
                </div>
                <select name="rol" class="form-control">
                <option selected disabled >Elige un rol para este usuario...</option>
                @foreach($roles as $role)
                    @if($role->nombre == str_replace(array('["','"]'), '', $user->tieneRol()))
                        <option value="{{$role->id}}"selected>{{$role->nombre}} </option>
                    @else
                        <option value="{{$role->id}}">{{$role->nombre}} </option>
                    @endif
                @endforeach
              </select>
              </div>
            </div>

            <div class="bmd-form-group{{ $errors->has('descripcion') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">description</i>
                  </span>
                </div>
                <input type="text" name="descripcion" class="form-control" placeholder="{{ __('Descripción del Rol') }}" value="{{ $user->descripcion }}" required>
              </div>
              @if ($errors->has('descripcion'))
                <div id="descripcion" class="error text-danger pl-3" for="descripcion" style="display: block;">
                  <strong>{{ $errors->first('descripcion') }}</strong>
                </div>
              @endif
            </div>

            <div class="bmd-form-group{{ $errors->has('url') ? ' has-danger' : '' }}">
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">
                      <i class="material-icons">link</i>
                  </span>
                </div>
                <input type="text" name="url" class="form-control" placeholder="{{ __('Url') }}" value="{{ $user->url}}" required>
              </div>
              @if ($errors->has('url'))
                <div id="url" class="error text-danger pl-3" for="url" style="display: block;">
                  <strong>{{ $errors->first('url') }}</strong>
                </div>
              @endif
            </div>

            <!-- Nombre con imagen -->

            <div class="card-deck mt-3">

      <div class="card-group mt-3">
  
      <div class="card text-center border-info">
        <div class="card-body" style="background-color: #CCFAE5;" >
          <h4 class="card-title">Foto de perfil</h4>
        <div class="author">
          <img    src="{{asset('fotoperfil/'.$user->imagen)}}" style="width: 25%; height: 25%;">
          <br>
          <input type="file" name="imagen"  id="file" accept="image/*" capture="camera"  /> 

        </div>
        </div>
      </div>  
      
       <!-- Fin de Nombre con imagen -->

       <!-- Card de QR -->

      <div class="card text-center border-info">
        <div class="card-body" style="background-color: #F7B793;">
          <h4 class="card-title">Codigo QR</h4>
          <p class="card-text">Para generar el codigo QR del colaborador es necesario acceder
                                  a la ruta <a href="https://www.qrcode-monkey.com/">https://www.qrcode-monkey.com/</a>
                                  y colocar la URL generada en la parte de arriba para que posteriormente sea descargado
                                  este QR y asi mismo sea guardada en esta seccion. </p>
          <img  src="{{asset('fotoqr/'.$user->imagen2)}}" style="width: 50%; height: 50%;">
          <br> 
          <br>
          <input type="file" name="imagen2"  id="file" accept="image/*" capture="camera"  /> 


        </div>
      </div>          
      <!-- Fin de Card de QR -->


          </div>
          <div class="card-footer justify-content-center">
            <button type="submit" class="btn btn-primary">{{ __('ACTUALIZAR') }}</button>
          </div>
            </div>
      
    
      </div>

    </div>
  </div>
@endsection