@extends('layouts.app', ['activePage' => 'usuariostable', 'titlePage' => __('Lista de Usuarios')])
@section('content')

<div class="content">


 <div class="container-fluid">
  <div class="row">
@can('Administrador')
  <div class="d-grid gap-2 d-md-flex justify-content-md-end">
        <a href="usuarios/create">
        <button type="button" class="btn btn-info">
        Agregar Usuario</button> </a>
    </div>

   <div class="col-md-12">
    <div class="card">
        <div class="card-header card-header-primary">
            <h4 class="card-title ">Tabla de Usuarios</h4>
        </div>
            <div class="card-body">
                <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                        <th scope="col">ID Empleado</th>
                        <th scope="col">Nombre</th>
                        
                        <th scope="col">Correo</th>
                        <th scope="col">Rol</th>
                        <th scope="col">Creado</th>

                         @endcan
                        @can('Administrador')
                        <th scope="col">Opciones</th>
                        @endcan
                        </tr>
                    </thead>
                     <tbody>
                    @foreach($users as $user)
                        <tr>
                        <th scope="row">{{$user->idEmpleado}}</th>
                        <td>{{$user->name}} {{$user->ap}} {{$user->am}}</td>
                        <td>{{$user->email}}</td>
                        <td> 
                            @foreach($user->roles as $role)
                                {{$role->nombre}}
                            @endforeach
                        </td>
                        <td>{{$user->created_at}}</td>
                        

                        @can('Administrador')
                        <td class="td-actions text-left">
                            <form action="{{route('usuarios.destroy', $user->id)}}" method="POST" class="eliminar">
                               
                                <a href="{{ route('usuarios.show', $user->id)}}" >
                                <button type="button"  class="btn btn-primary" >
                                <i class="material-icons">visibility</i> 
                                </button> </a> 

                                <a href="{{ route('usuarios.edit', $user->id)}}" >
                                <button type="button"  class="btn btn-success" >
                                <i class="material-icons">edit</i> 
                                </button> </a> 
                                @csrf 
                                @method('DELETE')
                                <button type="submit" rel="tooltip" class="btn btn-danger">
                                <i class="material-icons">close</i>
                            </button>
                            </form>
                            
                        </td> @endcan
                        </tr>
                    @endforeach    
                    </tbody> 
                    </table>

                     

                    

                </div>
                <div class="row">
                        <div class="mx-auto">
                            {{$users->appends($_GET)->links()}}
                        </div>
                    </div>  
                </div>
   </div>
  </div>
 </div>
</div>
     
@endsection

@section('js')
<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <script>
    $('.eliminar').submit(function(e){
        e.preventDefault();
        Swal.fire({
        title: '¿Deseas eliminar?',
        text: "¡Esta acción no se puede revertir!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si,eliminar',
        cancelButtonText: 'Cancelar'
        }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire(
            'Datos Eliminados!',
            'eliminación correcta',
            'success'
            )
            this.submit();
        }
        })
    });    
    </script>

@endsection