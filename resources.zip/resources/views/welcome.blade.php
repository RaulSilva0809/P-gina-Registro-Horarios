@extends('layouts.app', ['class' => 'off-canvas-sidebar', 'activePage' => 'home', 'title' => __('TERZETT TECHNOLOGIX')])

@section('content')
<div class="container" style="height: auto;">
  <div class="row justify-content-center">
      
  </div>

  
   
</div>




@endsection
